package org.example;

import com.itextpdf.html2pdf.ConverterProperties;
import com.itextpdf.html2pdf.HtmlConverter;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import org.apache.commons.io.FileUtils;


public class BankStatementToPDF {

    public static void main(String[] args) throws IOException {

        try {

            File file = new File("./statements.json");
            String content = FileUtils.readFileToString(file, "utf-8");

            String base64 = convertJsonToPdf(new JSONObject(content));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static String convertJsonToPdf(JSONObject jsonData) {

        try {

            StringBuilder htmlContent = new StringBuilder();
            htmlContent.append("<html><body>");
            JSONObject customerData = jsonData.getJSONObject("Customer Data");
            JSONObject bankData = jsonData.getJSONObject("Bank Details");
            String bankNameLine = "<h1 style=\"text-align:center\">"+bankData.getString("bank")+"</h1>";
            htmlContent.append(bankNameLine);


            htmlContent.append("<div style=\"float:left;  width: 50%;\">");
            htmlContent.append("<p>Customer Name: ").append(customerData.getString("name")).append("</p>");
            htmlContent.append("<p>Address: ").append(customerData.getString("address")).append("</p>");
            htmlContent.append("<p>Account no: ").append(bankData.getString("accountNo")).append("</p>");
            htmlContent.append("<p>AccountType: ").append(bankData.getString("accountType")).append("</p>");

            htmlContent.append("</div>");

            htmlContent.append("<div style=\"float: right;\">");
            htmlContent.append("<p>Start Date: ").append(customerData.getString("startDate")).append("</p>");
            htmlContent.append("<p>End Date: ").append(customerData.getString("endDate")).append("</p>");
            htmlContent.append("<p>Duration Month: ").append(customerData.getString("durationInMonths")).append("</p>");
            htmlContent.append("<p>Source Data: ").append(customerData.getString("sourceOfData")).append("</p>");
            String currentDate = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
            htmlContent.append("<p>Date of Statement Generation: ").append(currentDate).append("</p>");
            htmlContent.append("</div>");

            htmlContent
                    .append("<div style='display: inline-block;padding:5px'>")
                    .append("<p style=\"text-align:center\"><strong>Statement of Account No: ")
                    .append(bankData.getString("accountNo"))
                    .append(" for the period (From: ")
                    .append(customerData.getString("startDate"))
                    .append(" To: ")
                    .append(customerData.getString("endDate"))
                    .append(")</strong></p>")
                    .append("</div>");

            JSONArray statementSummary = jsonData.getJSONArray("Statement Summary");
            htmlContent.append("<br>");

            htmlContent.append("<style>");
            htmlContent.append("table { width: 100%; border-collapse: collapse; }");
            htmlContent.append("table, th, td { border: 1px solid black; }");
            htmlContent.append("td { word-wrap: break-word; max-width: 100px; font-size:12px; text-align:center }"); // Adjust max-width as needed
            htmlContent.append("</style>");
            htmlContent.append("<table>");
            htmlContent.append("<tr><th>Date</th><th>Transaction No</th><th>Category</th><th>Narration</th><th>Deposit Amount</th><th>Withdrawal Amount</th><th>Balance</th></tr>");

            double totalDeposit = 0.0;
            double totalWithdrawal = 0.0;
            double totalBalance = 0.0;

            for (int i = 0; i < statementSummary.length(); i++) {
                JSONObject transactionObj = statementSummary.getJSONObject(i);
                htmlContent.append("<tr>");
                htmlContent.append("<td>").append(transactionObj.getString("date")).append("</td>");
                htmlContent.append("<td>").append(transactionObj.getString("chqNo")).append("</td>");
                htmlContent.append("<td>").append(transactionObj.getString("category")).append("</td>");
                htmlContent.append("<td>").append(transactionObj.getString("narration")).append("</td>");
                double amount = Double.parseDouble(transactionObj.getString("amount"));
                if (amount >= 0) {
                    htmlContent.append("<td>").append(amount).append("</td>");
                    htmlContent.append("<td></td>");
                } else {
                    htmlContent.append("<td></td>");
                    htmlContent.append("<td> -").append(Math.abs(amount)).append("</td>");
                }
                htmlContent.append("<td>").append(transactionObj.getString("balance")).append("</td>");
                htmlContent.append("</tr>");

                double balance = Double.parseDouble(transactionObj.getString("balance"));

                DecimalFormat decimalFormat = new DecimalFormat("#.##"); // Format to two decimal places

                if (amount >= 0) {
                    totalDeposit += amount;
                    totalDeposit=Double.parseDouble(decimalFormat.format(totalDeposit));

                } else {
                    totalWithdrawal -= amount; // Convert negative value to positive
                    totalWithdrawal=Double.parseDouble(decimalFormat.format(totalWithdrawal));
                }
                totalBalance += balance;
                totalBalance=Double.parseDouble(decimalFormat.format(totalBalance));
            }


            htmlContent.append("<tr><td colspan=\"4\"><b>Total</b></td>");
            htmlContent.append("<td>").append(totalDeposit).append("</td>");
            htmlContent.append("<td>-").append(totalWithdrawal).append("</td>");
            htmlContent.append("<td>").append(totalBalance).append("</td></tr>");

            htmlContent.append("</body></html>");

            ByteArrayOutputStream pdfOutputStream = new ByteArrayOutputStream();
            ConverterProperties converterProperties = new ConverterProperties();
            HtmlConverter.convertToPdf(htmlContent.toString(), pdfOutputStream, converterProperties);

            byte[] pdfBytes = pdfOutputStream.toByteArray();
            String base64PDF = java.util.Base64.getEncoder().encodeToString(pdfBytes);

            System.out.println("Base64 PDF: " + base64PDF);

            return base64PDF;

        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

    }

}


